//2d
/* 
Author:Mosée
Date:17/10/2024
*/
#include <stdio.h>

int main (){
int i,j;
int marks [2][3]={{12,13,34},{34,54,65}};

for(i=0;i<2;i++){
for(j=0;j<3;j++){
printf("the mark[%d][%d]=%d\n",i,j,marks [i][j]);




}

}









return 0 ;
}